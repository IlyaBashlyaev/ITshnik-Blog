# Миграция MySQL базы данных WordPress
#
# Сформирован: Friday 27. June 2025 11:02 UTC
# Адрес сайта: localhost
# База данных: `blog`
# URL: //itshnik.42web.io
# Path: /Users/ilya/Sites/Blog
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_quads_stats, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, page, polylang_mo, post, wp_global_styles
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Удалить любую существующую таблицу `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Структура таблицы `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_commentmeta`
#

#
# Конец содержимого данных таблицы `wp_commentmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Структура таблицы `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_comments`
#

#
# Конец содержимого данных таблицы `wp_comments`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Структура таблицы `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_links`
#

#
# Конец содержимого данных таблицы `wp_links`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Структура таблицы `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=2450 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://itshnik.42web.io', 'yes'),
(2, 'home', 'http://itshnik.42web.io', 'yes'),
(3, 'blogname', 'ITshnik - Блог о мире IT', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'i.bashlyaev@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:29:"website-info/website-info.php";i:2;s:29:"wp-downgrade/wp-downgrade.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'Blog', 'yes'),
(41, 'stylesheet', 'Blog', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'contributor', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:30:"conveythis-translate/index.php";a:2:{i:0;s:10:"ConveyThis";i:1;s:16:"plugin_uninstall";}}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '55', 'yes'),
(82, 'page_on_front', '55', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1766509592', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '49752', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:167:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:247:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(105, 'cron', 'a:10:{i:1751023458;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1751024211;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"4b4e209dc26cce1402f8f732cbf88d77";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:104;}}}}i:1751024474;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"852f65d39f49c1aacb393d661f8963f4";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:105;}}}}i:1751024635;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"7515a3c4f57d19f554c14e2c745faebf";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:106;}}}}i:1751030771;a:1:{s:17:"quads_daily_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1751042603;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1751055858;a:6:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1751056454;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1751203571;a:1:{s:18:"quads_weekly_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(106, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'theme_mods_twentytwentyone', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1640897169;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(120, 'recovery_keys', 'a:0:{}', 'yes'),
(121, 'https_detection_errors', 'a:2:{s:23:"ssl_verification_failed";a:1:{i:0;s:38:"Проверка SSL неудачна.";}s:17:"bad_response_code";a:1:{i:0;s:21:"Internal Server Error";}}', 'yes'),
(150, 'finished_updating_comment_type', '1', 'yes'),
(152, 'recently_activated', 'a:1:{s:31:"website-info-1/website-info.php";i:1751020474;}', 'yes'),
(153, 'current_theme', 'Blog', 'yes'),
(154, 'theme_mods_Blog', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(155, 'theme_switched', '', 'yes'),
(163, 'wp_dark_mode_version', '2.2.3', 'yes'),
(164, 'wp_dark_mode_install_time', '1640900017', 'yes'),
(170, 'wp_dark_mode_general', '', 'yes'),
(171, 'wp_dark_mode_advanced', '', 'yes'),
(172, 'wp_dark_mode_color', '', 'yes'),
(173, 'wp_dark_mode_switch', '', 'yes'),
(174, 'wp_dark_mode_includes_excludes', '', 'yes'),
(175, 'wp_dark_mode_triggers', '', 'yes'),
(176, 'wp_dark_mode_performance', '', 'yes'),
(177, 'wp_dark_mode_accessibility', '', 'yes'),
(178, 'wp_dark_mode_wc', '', 'yes'),
(179, 'wp_dark_mode_image_settings', '', 'yes'),
(180, 'wp_dark_mode_video_settings', '', 'yes'),
(181, 'wp_dark_mode_custom_css', '', 'yes'),
(182, 'wp_dark_mode_animation', '', 'yes'),
(183, 'wp_dark_mode_analytics_reporting', '', 'yes'),
(239, 'drdt-dark-options-settings', 'a:30:{s:8:"frontend";s:3:"yes";s:14:"enable_default";s:3:"yes";s:13:"color_backend";s:0:"";s:12:"button_style";s:1:"1";s:15:"button_position";s:12:"bottom-right";s:16:"content_position";s:2:"no";s:16:"exclude_elements";s:0:"";s:10:"custom_css";s:0:"";s:10:"brigthness";s:1:"1";s:8:"contrast";s:1:"1";s:8:"opacitys";s:1:"1";s:17:"select_categories";a:1:{i:0;s:3:"all";}s:23:"select_categories_color";s:0:"";s:12:"select_posts";a:1:{i:0;s:3:"all";}s:17:"select_post_color";s:0:"";s:20:"select_woocategories";a:1:{i:0;s:3:"all";}s:16:"select_woo_color";s:0:"";s:15:"select_products";a:1:{i:0;s:3:"all";}s:20:"select_woosing_color";s:0:"";s:13:"color_palette";s:1:"2";s:9:"custom_bg";s:7:"#000000";s:11:"custom_body";s:7:"#000000";s:11:"custom_head";s:7:"#000000";s:11:"custom_link";s:7:"#000000";s:17:"custom_link_hover";s:7:"#000000";s:10:"custom_btn";s:7:"#000000";s:13:"custom_border";s:7:"#000000";s:10:"image_dark";a:1:{i:0;a:2:{s:6:"normal";s:0:"";s:4:"dark";s:0:"";}}s:10:"start_time";s:0:"";s:8:"end_time";s:0:"";}', 'yes'),
(274, 'polylang', 'a:14:{s:7:"browser";b:1;s:7:"rewrite";i:1;s:12:"hide_default";i:1;s:10:"force_lang";i:2;s:13:"redirect_lang";i:0;s:13:"media_support";b:0;s:9:"uninstall";i:0;s:4:"sync";a:0:{}s:10:"post_types";a:0:{}s:10:"taxonomies";a:0:{}s:7:"domains";a:0:{}s:7:"version";s:5:"3.1.3";s:16:"first_activation";i:1641066654;s:12:"default_lang";s:2:"ru";}', 'yes'),
(275, 'polylang_wpml_strings', 'a:0:{}', 'yes'),
(276, 'widget_polylang', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(303, 'category_children', 'a:0:{}', 'yes'),
(367, 'GTranslate', 'a:35:{s:11:"pro_version";s:0:"";s:18:"enterprise_version";s:0:"";s:14:"custom_domains";s:0:"";s:19:"custom_domains_data";s:0:"";s:15:"url_translation";s:0:"";s:17:"add_hreflang_tags";s:0:"";s:17:"email_translation";s:0:"";s:23:"email_translation_debug";s:0:"";s:10:"new_window";s:0:"";s:12:"show_in_menu";s:0:"";s:26:"floating_language_selector";s:2:"no";s:21:"native_language_names";s:0:"";s:23:"detect_browser_language";s:0:"";s:12:"add_new_line";s:1:"1";s:16:"default_language";s:2:"ru";s:18:"translation_method";s:5:"onfly";s:11:"widget_look";s:19:"dropdown_with_flags";s:9:"flag_size";s:2:"24";s:10:"flag_style";s:2:"3d";s:16:"monochrome_flags";s:0:"";s:11:"widget_code";s:0:"";s:10:"incl_langs";a:10:{i:0;s:2:"en";i:1;s:2:"es";i:2;s:2:"it";i:3;s:2:"pt";i:4;s:2:"de";i:5;s:2:"fr";i:6;s:2:"ru";i:7;s:2:"nl";i:8;s:2:"ar";i:9;s:5:"zh-CN";}s:11:"fincl_langs";a:10:{i:0;s:2:"en";i:1;s:2:"es";i:2;s:2:"it";i:3;s:2:"pt";i:4;s:2:"de";i:5;s:2:"fr";i:6;s:2:"ru";i:7;s:2:"nl";i:8;s:2:"ar";i:9;s:5:"zh-CN";}s:9:"alt_flags";a:0:{}s:19:"switcher_text_color";s:4:"#666";s:20:"switcher_arrow_color";s:4:"#666";s:21:"switcher_border_color";s:4:"#ccc";s:25:"switcher_background_color";s:4:"#fff";s:32:"switcher_background_shadow_color";s:7:"#efefef";s:31:"switcher_background_hover_color";s:4:"#fff";s:19:"dropdown_text_color";s:4:"#000";s:20:"dropdown_hover_color";s:4:"#fff";s:25:"dropdown_background_color";s:4:"#eee";s:14:"language_codes";s:320:"af,sq,am,ar,hy,az,eu,be,bn,bs,bg,ca,ceb,ny,zh-CN,zh-TW,co,hr,cs,da,nl,en,eo,et,tl,fi,fr,fy,gl,ka,de,el,gu,ht,ha,haw,iw,hi,hmn,hu,is,ig,id,ga,it,ja,jw,kn,kk,km,ko,ku,ky,lo,la,lv,lt,lb,mk,mg,ms,ml,mt,mi,mr,mn,my,ne,no,ps,fa,pl,pt,pa,ro,ru,sm,gd,sr,st,sn,sd,si,sk,sl,so,es,su,sw,sv,tg,ta,te,th,tr,uk,ur,uz,vi,cy,xh,yi,yo,zu";s:15:"language_codes2";s:320:"af,sq,am,ar,hy,az,eu,be,bn,bs,bg,ca,ceb,ny,zh-CN,zh-TW,co,hr,cs,da,nl,en,eo,et,tl,fi,fr,fy,gl,ka,de,el,gu,ht,ha,haw,iw,hi,hmn,hu,is,ig,id,ga,it,ja,jw,kn,kk,km,ko,ku,ky,lo,la,lv,lt,lb,mk,mg,ms,ml,mt,mi,mr,mn,my,ne,no,ps,fa,pl,pt,pa,ro,ru,sm,gd,sr,st,sn,sd,si,sk,sl,so,es,su,sw,sv,tg,ta,te,th,tr,uk,ur,uz,vi,cy,xh,yi,yo,zu";}', 'yes'),
(368, 'widget_gtranslate', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(369, 'gtranslate_admin_notice', 'a:2:{s:15:"two_week_review";a:2:{s:5:"start";s:8:"1/6/2022";s:3:"int";i:5;}s:12:"upgrade_tips";a:2:{s:5:"start";s:8:"1/3/2022";s:3:"int";i:2;}}', 'yes'),
(370, 'rewrite_rules', 'a:97:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=55&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(405, 'widget_conveythis', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(414, 'googlelanguagetranslator_active', '1', 'yes'),
(415, 'googlelanguagetranslator_language', 'ru', 'yes'),
(416, 'googlelanguagetranslator_flags', '1', 'yes'),
(417, 'language_display_settings', 'a:2:{s:2:"en";s:1:"1";s:2:"uk";s:1:"1";}', 'yes'),
(418, 'googlelanguagetranslator_translatebox', 'yes', 'yes'),
(419, 'googlelanguagetranslator_display', 'Vertical', 'yes'),
(420, 'googlelanguagetranslator_toolbar', 'Yes', 'yes'),
(421, 'googlelanguagetranslator_showbranding', 'Yes', 'yes'),
(422, 'googlelanguagetranslator_flags_alignment', 'flags_left', 'yes'),
(423, 'googlelanguagetranslator_analytics', '', 'yes'),
(424, 'googlelanguagetranslator_analytics_id', '', 'yes'),
(425, 'googlelanguagetranslator_css', '', 'yes'),
(426, 'googlelanguagetranslator_multilanguage', '', 'yes'),
(427, 'googlelanguagetranslator_floating_widget', 'yes', 'yes'),
(428, 'googlelanguagetranslator_flag_size', '18', 'yes'),
(429, 'googlelanguagetranslator_flags_order', '', 'yes'),
(430, 'googlelanguagetranslator_english_flag_choice', 'us_flag', 'yes'),
(431, 'googlelanguagetranslator_spanish_flag_choice', 'spanish_flag', 'yes'),
(432, 'googlelanguagetranslator_portuguese_flag_choice', 'portuguese_flag', 'yes'),
(433, 'googlelanguagetranslator_floating_widget_text', 'Translate »', 'yes'),
(434, 'googlelanguagetranslator_floating_widget_text_allow_translation', '', 'yes'),
(435, 'widget_glt_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(436, 'glt_admin_notice', 'a:3:{s:16:"glt_announcement";a:3:{s:5:"start";s:8:"1/1/2022";s:3:"int";i:0;s:9:"dismissed";i:1;}s:15:"two_week_review";a:2:{s:5:"start";s:8:"1/6/2022";s:3:"int";i:5;}s:12:"upgrade_tips";a:2:{s:5:"start";s:8:"1/3/2022";s:3:"int";i:2;}}', 'yes'),
(437, 'googlelanguagetranslator_seo_active', '', 'yes'),
(438, 'googlelanguagetranslator_url_structure', 'sub_domain', 'yes'),
(439, 'googlelanguagetranslator_url_translation_active', '', 'yes'),
(440, 'googlelanguagetranslator_hreflang_tags_active', '', 'yes'),
(441, 'glt_language_switcher_width', '100%', 'yes'),
(442, 'glt_language_switcher_text_color', '#32373c', 'yes'),
(443, 'glt_language_switcher_bg_color', '', 'yes'),
(444, 'glt_floating_widget_position', 'bottom_left', 'yes'),
(445, 'glt_floating_widget_text_color', '#ffffff', 'yes'),
(446, 'glt_floating_widget_bg_color', '#f89406', 'yes'),
(451, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(452, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(494, 'new_admin_email', 'i.bashlyaev@gmail.com', 'yes'),
(507, 'rocket_cache_dir_size_check', '1', 'yes'),
(524, 'wp_rocket_resources_scanner', 'a:4:{s:16:"http://blog.com/";a:2:{s:4:"type";s:10:"front_page";s:3:"url";s:16:"http://blog.com/";}s:26:"http://blog.com/copyright/";a:2:{s:4:"type";s:4:"page";s:3:"url";s:26:"http://blog.com/copyright/";}s:83:"http://blog.com/2021/12/30/%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80/";a:2:{s:4:"type";s:4:"post";s:3:"url";s:83:"http://blog.com/2021/12/30/%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80/";}s:87:"http://blog.com/category/%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8/";a:2:{s:4:"type";s:8:"category";s:3:"url";s:87:"http://blog.com/category/%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8/";}}', 'yes'),
(525, 'wp_rocket_resources_scanner_scanned', 'a:4:{i:0;s:16:"http://blog.com/";i:1;s:26:"http://blog.com/copyright/";i:2;s:83:"http://blog.com/2021/12/30/%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80/";i:3;s:87:"http://blog.com/category/%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8/";}', 'yes'),
(526, 'wp_rocket_resources_scanner_fetched', 'a:4:{s:16:"http://blog.com/";a:2:{s:3:"url";s:16:"http://blog.com/";s:8:"is_error";b:0;}s:26:"http://blog.com/copyright/";a:2:{s:3:"url";s:26:"http://blog.com/copyright/";s:8:"is_error";b:0;}s:83:"http://blog.com/2021/12/30/%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80/";a:2:{s:3:"url";s:83:"http://blog.com/2021/12/30/%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80/";s:8:"is_error";b:0;}s:87:"http://blog.com/category/%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8/";a:2:{s:3:"url";s:87:"http://blog.com/category/%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8/";s:8:"is_error";b:0;}}', 'yes'),
(527, 'wp_rocket_prewarmup_stats', 'a:5:{s:15:"scan_start_time";i:1641125751;s:17:"fetch_finish_time";i:1641460366;s:23:"resources_scanner_count";i:4;s:18:"allow_optimization";b:1;s:25:"warmup_status_finish_time";i:1641125785;}', 'yes'),
(598, 'quads_settings', 'a:15:{s:10:"post_types";a:1:{i:0;s:4:"post";}s:10:"visibility";a:4:{s:7:"AppHome";s:1:"1";s:7:"AppCate";s:1:"1";s:7:"AppArch";s:1:"1";s:7:"AppTags";s:1:"1";}s:9:"quicktags";a:1:{s:7:"QckTags";s:1:"1";}s:3:"ads";a:20:{s:3:"ad1";a:11:{s:5:"label";s:4:"Ad 1";s:7:"ad_type";s:7:"adsense";s:4:"code";s:402:"<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8485558309118681" crossorigin="anonymous"></script>\r\n<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-8485558309118681" data-ad-slot="7902905163" data-ad-format="auto" data-full-width-responsive="true"></ins>\r\n<script>\r\n    (adsbygoogle = window.adsbygoogle || []).push({});\r\n</script>";s:14:"g_data_ad_slot";s:10:"7902905163";s:16:"g_data_ad_client";s:23:"ca-pub-8485558309118681";s:12:"adsense_type";s:10:"responsive";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"1";s:6:"margin";s:2:"25";s:15:"current_ad_type";s:12:"google_async";}s:3:"ad2";a:10:{s:5:"label";s:4:"Ad 2";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:3:"ad3";a:10:{s:5:"label";s:4:"Ad 3";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:3:"ad4";a:10:{s:5:"label";s:4:"Ad 4";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:3:"ad5";a:10:{s:5:"label";s:4:"Ad 5";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:3:"ad6";a:10:{s:5:"label";s:4:"Ad 6";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:3:"ad7";a:10:{s:5:"label";s:4:"Ad 7";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:3:"ad8";a:10:{s:5:"label";s:4:"Ad 8";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:3:"ad9";a:10:{s:5:"label";s:4:"Ad 9";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:4:"ad10";a:10:{s:5:"label";s:5:"Ad 10";s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:6:"margin";s:1:"0";}s:10:"ad1_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad2_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad3_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad4_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad5_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad6_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad7_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad8_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:10:"ad9_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}s:11:"ad10_widget";a:16:{s:7:"ad_type";s:10:"plain_text";s:4:"code";s:0:"";s:14:"g_data_ad_slot";s:0:"";s:16:"g_data_ad_client";s:0:"";s:12:"adsense_type";s:6:"normal";s:15:"g_data_ad_width";s:0:"";s:16:"g_data_ad_height";s:0:"";s:5:"align";s:1:"3";s:9:"margintop";s:1:"0";s:11:"marginright";s:1:"0";s:12:"marginbottom";s:1:"0";s:10:"marginleft";s:1:"0";s:10:"paddingtop";s:1:"0";s:12:"paddingright";s:1:"0";s:13:"paddingbottom";s:1:"0";s:11:"paddingleft";s:1:"0";}}s:6:"maxads";s:3:"100";s:4:"pos1";a:2:{s:7:"BegnAds";s:1:"1";s:7:"BegnRnd";s:1:"0";}s:4:"pos2";a:2:{s:7:"MiddAds";s:1:"1";s:7:"MiddRnd";s:1:"1";}s:4:"pos3";a:1:{s:7:"EndiRnd";s:1:"0";}s:4:"pos4";a:1:{s:7:"MoreRnd";s:1:"0";}s:4:"pos5";a:1:{s:7:"LapaRnd";s:1:"0";}s:4:"pos6";a:2:{s:7:"Par1Rnd";s:1:"0";s:7:"Par1Nup";s:1:"1";}s:4:"pos7";a:2:{s:7:"Par2Rnd";s:1:"0";s:7:"Par2Nup";s:1:"1";}s:4:"pos8";a:2:{s:7:"Par3Rnd";s:1:"0";s:7:"Par3Nup";s:1:"1";}s:4:"pos9";a:2:{s:7:"Img1Rnd";s:1:"0";s:7:"Img1Nup";s:1:"1";}s:8:"priority";s:2:"10";}', 'yes'),
(599, 'quads_vi_settings', 'O:8:"stdClass":3:{s:6:"status";s:2:"ok";s:5:"error";N;s:4:"data";O:8:"stdClass":15:{s:9:"signupURL";s:41:"https://www.vi.ai/publisher-registration/";s:12:"dashboardURL";s:23:"https://dashboard.vi.ai";s:13:"directSellURL";s:46:"https://www.vi.ai/publisher-video-monetization";s:11:"demoPageURL";s:44:"http://demo.vi.ai/ViewsterBlog_Nintendo.html";s:8:"loginAPI";s:52:"https://dashboard-api.vidint.net/v1/api/authenticate";s:10:"revenueAPI";s:65:"https://dashboard-api.vidint.net/v1/api/publishers/report/revenue";s:8:"jsTagAPI";s:58:"https://dashboard-api.vidint.net/v1/api/applications/jstag";s:16:"iabCategoriesURL";s:55:"https://docs.vi.ai/integrations/list-of-iab-categories/";s:9:"adsTxtAPI";s:58:"https://dashboard-api.vidint.net/v1/api/publishers/ads-txt";s:20:"setCookieAndRedirect";s:45:"https://dashboard-api-test.vidint.net/v1/scar";s:13:"vendorListURL";s:21:"https://vi.ai/vendors";s:17:"vendorListVersion";s:1:"1";s:19:"consentPopupContent";O:8:"stdClass":3:{s:2:"en";s:241:"<p>Click below to consent to the use of the cookie technology provided by vi (video intelligence AG) to personalize content and advertising. For more info please access <a target="_blank" href="https://www.vi.ai/legals">vi\'s website</a>.</p>";s:2:"fr";s:263:"<p>Pulse abajo para aceptar el uso de la tecnología de cookie proporcionada por vi (video intelligence AG) para personalizar el contenido y la publicidad. Para más información, acceda al<a target="_blank" href="https://www.vi.ai/legals"sitio web de vi</a>.</p>";s:2:"es";s:288:"<p>Cliquez ci-dessous pour accepter l\'utilisation de la technologie des cookies fournie par vi (video intelligence AG) pour personnaliser le contenu et la publicité. Pour plus d\'informations, veuillez accéder au <a target="_blank" href="https://www.vi.ai/legals">site web de vi</a>.</p>";}s:8:"purposes";a:5:{i:0;O:8:"stdClass":3:{s:2:"id";i:1;s:4:"name";s:33:"Storage and access of information";s:11:"description";O:8:"stdClass":3:{s:2:"en";s:212:"The storage of information, or access to information that is already stored, on your device such as accessing advertising identifiers and/or other device identifiers, and/or using cookies or similar technologies.";s:2:"de";s:230:"Speicherung von Informationen oder Zugriff auf Informationen, die bereits auf Ihrem Gerät gespeichert sind, z. B. Zugriff auf Werbe-IDs und / oder andere Geräte-IDs und / oder Verwendung von Cookies oder ähnlichen Technologien.";s:2:"fr";s:259:"Le stockage d\'informations ou l\'accès à des informations déjà stockées sur votre appareil, telles que l\'accès à des identifiants publicitaires et / ou à d\'autres identifiants d\'appareils, et / ou l\'utilisation de cookies ou de technologies similaires.";}}i:1;O:8:"stdClass":3:{s:2:"id";i:2;s:4:"name";s:15:"Personalisation";s:11:"description";O:8:"stdClass":3:{s:2:"en";s:301:"The collection and processing of information about your use of this site to subsequently personalize advertising for you in other contexts, i.e. on other sites or apps, over time. Typically, the content of the site or app is used to make inferences about your interests which inform future selections.";s:2:"de";s:357:"Die Sammlung und Verarbeitung von Informationen über Ihre Nutzung dieser Website, um die Werbung für Sie in anderen Kontexten, d. H. Auf anderen Websites oder in Apps, im Laufe der Zeit zu personalisieren. In der Regel wird der Inhalt der Website oder App verwendet, um Rückschlüsse auf Ihre Interessen zu ziehen, die zukünftige Auswahlen beeinflussen.";s:2:"fr";s:379:"La collecte et le traitement d\'informations sur votre utilisation de ce site pour ensuite personnaliser la publicité pour vous dans d\'autres contextes, c\'est-à-dire sur d\'autres sites ou applications, au fil du temps. En règle générale, le contenu du site ou de l\'application est utilisé pour faire des inférences sur vos intérêts qui éclairent les sélections futures.";}}i:2;O:8:"stdClass":3:{s:2:"id";i:3;s:4:"name";s:33:"Ad selection, delivery, reporting";s:11:"description";O:8:"stdClass":3:{s:2:"en";s:525:"The collection of information, and combination with previously collected information, to select and deliver advertisements for you, and to measure the delivery and effectiveness of such advertisements. This includes using previously collected information about your interests to select ads, processing data about what advertisements were shown, how often they were shown, when and where they were shown, and whether you took any action related to the advertisement, including for example clicking an ad or making a purchase. ";s:2:"de";s:576:"Die Sammlung von Informationen und die Kombination mit zuvor gesammelten Informationen, um Werbung für Sie auszuwählen und zu liefern und die Lieferung und Wirksamkeit solcher Werbung zu messen. Dies beinhaltet die Verwendung zuvor gesammelter Informationen über Ihre Interessen zur Auswahl von Anzeigen, die Verarbeitung von Daten darüber, welche Werbeanzeigen gezeigt wurden, wie oft sie gezeigt wurden, wann und wo sie gezeigt wurden und ob Sie irgendwelche Maßnahmen im Zusammenhang mit der Werbung ergriffen haben, einschließlich z Anzeige oder einen Kauf tätigen.";s:2:"fr";s:524:"La collecte d\'informations, et la combinaison avec des informations précédemment collectées, pour sélectionner et livrer des publicités pour vous, et pour mesurer la livraison et l\'efficacité de ces publicités. Cela inclut l\'utilisation d\'informations précédemment collectées sur vos centres d\'intérêt pour sélectionner des publicités, le traitement des données affichées, la fréquence à laquelle elles ont été diffusées, le moment et l\'endroit où elles ont été diffusées. annonce ou faire un achat.";}}i:3;O:8:"stdClass":3:{s:2:"id";i:4;s:4:"name";s:38:"Content selection, delivery, reporting";s:11:"description";O:8:"stdClass":3:{s:2:"en";s:495:"The collection of information, and combination with previously collected information, to select and deliver content for you, and to measure the delivery and effectiveness of such content. This includes using previously collected information about your interests to select content, processing data about what content was shown, how often or how long it was shown, when and where it was shown, and whether the you took any action related to the content, including for example clicking on content. ";s:2:"de";s:550:"Die Sammlung von Informationen und die Kombination mit zuvor gesammelten Informationen, um Inhalte für Sie auszuwählen und zu liefern und die Lieferung und Effektivität solcher Inhalte zu messen. Dies beinhaltet die Verwendung zuvor gesammelter Informationen über Ihre Interessen, um Inhalte auszuwählen, Daten darüber zu verarbeiten, welcher Inhalt gezeigt wurde, wie oft oder wie lange er angezeigt wurde, wann und wo er gezeigt wurde und ob Sie irgendwelche Maßnahmen in Bezug auf den Inhalt ergriffen haben zum Beispiel klicken auf Inhalt.";s:2:"fr";s:527:"La collecte d\'informations, et la combinaison avec des informations précédemment collectées, pour sélectionner et livrer du contenu pour vous, et pour mesurer la livraison et l\'efficacité de ce contenu. Cela inclut l\'utilisation d\'informations précédemment collectées sur vos centres d\'intérêt pour sélectionner du contenu, traiter le contenu affiché, combien de fois ou combien de temps il a été diffusé, quand et où il a été diffusé, et si vous avez pris des mesures par exemple en cliquant sur le contenu.";}}i:4;O:8:"stdClass":3:{s:2:"id";i:5;s:4:"name";s:11:"Measurement";s:11:"description";O:8:"stdClass":3:{s:2:"en";s:185:"The collection of information about your use of the content, and combination with previously collected information, used to measure, understand, and report on your usage of the content.";s:2:"de";s:219:"Die Sammlung von Informationen über Ihre Nutzung des Inhalts und die Kombination mit zuvor gesammelten Informationen, die verwendet werden, um Ihre Nutzung des Inhalts zu messen, zu verstehen und darüber zu berichten.";s:2:"fr";s:213:"La collecte d\'informations sur votre utilisation du contenu et la combinaison avec des informations précédemment collectées, utilisées pour mesurer, comprendre et rendre compte de votre utilisation du contenu.";}}}s:9:"languages";a:3:{i:0;O:8:"stdClass":1:{s:5:"en-us";s:7:"English";}i:1;O:8:"stdClass":1:{s:5:"de-de";s:7:"Deutsch";}i:2;O:8:"stdClass":1:{s:5:"fr-fr";s:9:"Français";}}}}', 'yes'),
(600, 'quads-mode', 'old', 'yes'),
(603, 'quads_install_date', '2022-01-02 01:26:12', 'yes'),
(604, 'quads_rating_div', 'no', 'yes'),
(605, 'quads_show_theme_notice', 'yes', 'yes'),
(608, 'quadsAdReset', '1', 'yes'),
(609, 'quadsAdResetDeleted', 'a:3:{s:10:"post_types";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:10:"visibility";a:4:{s:7:"AppHome";s:1:"1";s:7:"AppCate";s:1:"1";s:7:"AppArch";s:1:"1";s:7:"AppTags";s:1:"1";}s:9:"quicktags";a:1:{s:7:"QckTags";s:1:"1";}}', 'yes'),
(610, 'quadsAdReset_optionsDeleted', 'a:3:{s:10:"post_types";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:10:"visibility";a:4:{s:7:"AppHome";s:1:"1";s:7:"AppCate";s:1:"1";s:7:"AppArch";s:1:"1";s:7:"AppTags";s:1:"1";}s:9:"quicktags";a:1:{s:7:"QckTags";s:1:"1";}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(611, 'widget_quads_ads_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(614, 'quads_vi_variant', 'b', 'yes'),
(615, 'quads_version', '2.0.39', 'yes'),
(617, 'quads_hide_adpushup_notice', '1', 'yes'),
(618, 'quads_settings_backup', 'a:4:{s:10:"post_types";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:10:"visibility";a:4:{s:7:"AppHome";s:1:"1";s:7:"AppCate";s:1:"1";s:7:"AppArch";s:1:"1";s:7:"AppTags";s:1:"1";}s:9:"quicktags";a:1:{s:7:"QckTags";s:1:"1";}s:3:"ads";a:0:{}}', 'yes'),
(619, 'quads_vi_ads', '', 'yes'),
(635, 'w3tc_state', '{"common.install":1641131193,"common.install_version":"2.2.1","license.status":"no_key","license.next_check":1641563193,"license.terms":"","license.community_terms":"accept","common.show_note.plugins_updated":false,"common.show_note.plugins_updated.timestamp":1641465011,"common.show_note.flush_posts_needed":false,"common.show_note.flush_posts_needed.timestamp":1641465011}', 'no'),
(638, 'w3tc_generic_widgetservices', '{"content":{"items":[{"name":"Premium Support Response (Usually <1h First Response)","parameter_name":"field4","parameter_value":"Premium Support Response (Usually <1h First Response)","form_hash":"m5pom8z0qy59rm"},{"name":"Performance Audit \\/ Consult (Theme, Plugin, Content, Server)","parameter_name":"field4","parameter_value":"Performance Audit \\/ Consult (Theme, Plugin, Content, Server)","form_hash":"m5pom8z0qy59rm"},{"name":"Plugin Configuration","parameter_name":"field4","parameter_value":"Plugin Configuration","form_hash":"m5pom8z0qy59rm"},{"name":"SSL Performance Setup","parameter_name":"field4","parameter_value":"SSL Performance Setup","form_hash":"m5pom8z0qy59rm"},{"name":"Full Site Delivery Setup","parameter_name":"field4","parameter_value":"Full Site Delivery Setup","form_hash":"m5pom8z0qy59rm"},{"name":"Hosting Environment Troubleshooting","parameter_name":"field4","parameter_value":"Hosting Environment Troubleshooting","form_hash":"m5pom8z0qy59rm"},{"name":"Performance Monitoring","parameter_name":"field4","parameter_value":"Performance Monitoring","form_hash":"m5pom8z0qy59rm"}],"ui_strings":{"cdn.maxcdn.signUpAndSave":"Sign Up Now and save !","cdn.maxcdn.signUpAndSave.description":"MaxCDN is a service that lets you speed up your site even more with W3 Total Cache. Sign up now to recieve a special offer!","cdn.stackpath.signUpAndSave":"Sign Up Now and save !","cdn.stackpath.signUpAndSave.description":"StackPath is a service that lets you speed up your site even more with W3 Total Cache. Sign up now and save!","cdn.stackpath2.signUpAndSave":"Sign Up Now and save !","cdn.stackpath2.signUpAndSave.description":"StackPath is a service that lets you speed up your site even more with W3 Total Cache. Sign up now to recieve a special offer!","minify.general.header":"Reduce load time by decreasing the size and number of <acronym title=\'Cascading Style Sheet\'>CSS<\\/acronym> and <acronym title=\'JavaScript\'>JS<\\/acronym> files. Automatically remove unncessary data from <acronym title=\'Cascading Style Sheet\'>CSS<\\/acronym>, <acronym title=\'JavaScript\'>JS<\\/acronym>, feed, page and post <acronym title=\'Hypertext Markup Language\'>HTML<\\/acronym>.","newrelic.general.header":"New Relic may not be installed or not active on this server. <a href=\'%s\' target=\'_blank\'>Sign up for a (free) account<\\/a>. Visit <a href=\'%s\' target=\'_blank\'>New Relic<\\/a> for installation instructions.","reverseproxy.general.header":"A reverse proxy adds scale to an server by handling requests before WordPress does. Purge settings are set on the <a href=\'%s\'>Page Cache settings<\\/a> page and <a href=\'%s\'>Browser Cache settings<\\/a> are set on the browser cache settings page.","cdnfsd.general.header":"Host the entire website with your compatible <acronym title=\'Content Delivery Network\'>CDN<\\/acronym> provider to reduce page load time.","cdn.general.header":"Host static files with your <acronym title=\'Content Delivery Network\'>CDN<\\/acronym> to reduce page load time.","cdn.stackpath.widget.existing":"If you\'re an existing StackPath customer, enable <acronym title=\'Content Delivery Network\'>CDN<\\/acronym> and:","cdn.stackpath2.widget.existing":"If you\'re an existing StackPath customer, enable <acronym title=\'Content Delivery Network\'>CDN<\\/acronym> and:","cdn.stackpath2.widget.works_magically":"StackPath works magically with W3 Total Cache.","cdn.stackpath.widget.header":"Dramatically increase website speeds in just a few clicks! Add the StackPath content delivery network (<acronym title=\'Content Delivery Network\'>CDN<\\/acronym>) service to your site.","cdn.stackpath2.widget.header":"Dramatically increase website speeds in just a few clicks! Add the StackPath content delivery network (<acronym title=\'Content Delivery Network\'>CDN<\\/acronym>) service to your site."}},"expires":1642069477}', 'no'),
(670, 'ai-install', '1641150887', 'yes'),
(671, 'widget_ai_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(674, 'dst_notification_times', 'a:1:{s:11:"ad-inserter";i:1641150891;}', 'yes'),
(680, 'dst_optin_tracking', 'a:1:{s:11:"ad-inserter";i:1;}', 'yes'),
(683, 'dst_last_track_times', 'a:0:{}', 'yes'),
(763, 'acf_version', '6.0.6', 'yes'),
(854, 'googlesitekit_db_version', '1.3.0', 'yes'),
(855, 'googlesitekit_has_connected_admins', '0', 'yes'),
(889, 'googlesitekit_new_site_posts', '1', 'no'),
(891, 'googlesitekit_proxy_nonce', '7e89556ad9', 'yes'),
(894, 'googlesitekit_tracking_optin', '1', 'yes'),
(1392, 'w3tc_setupguide_completed', '1641464661', 'no'),
(1816, 'w3tc_browsercache_flush_timestamp', '80942', 'yes'),
(1890, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:21:"i.bashlyaev@gmail.com";s:7:"version";s:3:"5.9";s:9:"timestamp";i:1643395076;}', 'no'),
(1917, 'db_upgraded', '', 'yes'),
(1933, 'recovery_mode_email_last_sent', '1643396356', 'yes'),
(2130, 'wpdg_specific_version_name', '5.8.3', 'yes'),
(2131, 'wpdg_download_url', '', 'yes'),
(2132, 'wpdg_edit_download_url', '', 'yes'),
(2138, 'core_updater.lock', '1643477548', 'no'),
(2140, 'can_compress_scripts', '1', 'no'),
(2434, 'WEBSITE_INFO_API', '41FD9DB8-9E9C17CD-BFDAD920-22F559F9-6BC65A95', 'yes'),
(2447, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1751022143;}', 'no') ;

#
# Конец содержимого данных таблицы `wp_options`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Структура таблицы `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=330 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(10, 9, '_edit_lock', '1643611018:1'),
(11, 11, '_edit_lock', '1643579636:1'),
(14, 9, '_edit_last', '1'),
(15, 9, '_wp_page_template', 'articles.php'),
(16, 11, '_edit_last', '1'),
(17, 11, '_wp_page_template', 'article.php'),
(21, 13, '_edit_lock', '1725007026:1'),
(22, 15, '_edit_lock', '1643574395:1'),
(23, 13, '_edit_last', '1'),
(24, 13, '_wp_page_template', 'pages/about_me.php'),
(25, 15, '_edit_last', '1'),
(26, 15, '_wp_page_template', 'pages/copyright.php'),
(29, 20, '_pll_strings_translations', 'a:0:{}'),
(30, 21, '_pll_strings_translations', 'a:0:{}'),
(31, 22, '_pll_strings_translations', 'a:0:{}'),
(54, 34, '_edit_last', '1'),
(55, 34, '_edit_lock', '1724941251:1'),
(56, 1, '_edit_lock', '1673187577:1'),
(59, 1, '_edit_last', '1'),
(60, 1, 'articles', ''),
(61, 1, '_articles', 'field_61d44a6be06ed'),
(62, 1, 'title', 'Почему PHP - плохой язык программирования?'),
(63, 1, '_title', 'field_61d44b137cfc5'),
(64, 1, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(65, 1, '_text', 'field_61d44b917cfc6'),
(66, 1, 'category', 'Программирование'),
(67, 1, '_category', 'field_61d44bb77cfc7'),
(68, 1, 'image', '41'),
(69, 1, '_image', 'field_61d44cd27cfc8'),
(70, 40, 'articles', ''),
(71, 40, '_articles', 'field_61d44a6be06ed'),
(72, 40, 'title', ''),
(73, 40, '_title', 'field_61d44b137cfc5'),
(74, 40, 'text', ''),
(75, 40, '_text', 'field_61d44b917cfc6'),
(76, 40, 'category', 'Спорт'),
(77, 40, '_category', 'field_61d44bb77cfc7'),
(78, 40, 'image', ''),
(79, 40, '_image', 'field_61d44cd27cfc8'),
(89, 41, '_wp_attached_file', '2021/12/php.jpg'),
(90, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:425;s:6:"height";i:280;s:4:"file";s:15:"2021/12/php.jpg";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:15:"php-300x198.jpg";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:10:"image/jpeg";}s:9:"thumbnail";a:4:{s:4:"file";s:15:"php-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(93, 42, 'articles', ''),
(94, 42, '_articles', 'field_61d44a6be06ed'),
(95, 42, 'title', 'Почему PHP - плохой язык программирования?'),
(96, 42, '_title', 'field_61d44b137cfc5'),
(97, 42, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(98, 42, '_text', 'field_61d44b917cfc6'),
(99, 42, 'category', 'Программирование'),
(100, 42, '_category', 'field_61d44bb77cfc7'),
(101, 42, 'image', '41'),
(102, 42, '_image', 'field_61d44cd27cfc8'),
(109, 46, '_edit_lock', '1643486632:1'),
(110, 47, '_wp_attached_file', '2022/01/wordpress.png'),
(111, 47, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:21:"2022/01/wordpress.png";s:5:"sizes";a:2:{s:6:"medium";a:4:{s:4:"file";s:21:"wordpress-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"wordpress-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(114, 46, '_edit_last', '1'),
(115, 46, 'title', 'Преимущества Wordpress над другими CMS-системами'),
(116, 46, '_title', 'field_61d44b137cfc5'),
(117, 46, 'text', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est, sit veniam atque libero voluptatibus repellat pariatur earum natus eos! Reiciendis qui odit suscipit aliquid soluta pariatur, repudiandae in minus animi? Sunt, commodi. Accusantium quibusdam suscipit sint vitae sunt dolore quos quaerat. Maxime voluptate neque repellendus unde nisi deleniti doloribus, aut nulla quam enim dicta mollitia voluptatibus ex quis nostrum eveniet ut eum totam consequuntur aspernatur corrupti. Ab nostrum temporibus deserunt consequatur architecto eius reprehenderit quidem, quae sit saepe soluta voluptatum, autem necessitatibus voluptates quibusdam nemo. Enim porro repellat maxime fuga quis incidunt ad, officiis quod? Et, eius? Officia, ipsam tenetur!'),
(118, 46, '_text', 'field_61d44b917cfc6'),
(119, 46, 'category', 'Программирование'),
(120, 46, '_category', 'field_61d44bb77cfc7'),
(121, 46, 'image', '47'),
(122, 46, '_image', 'field_61d44cd27cfc8'),
(123, 49, 'title', 'Преимущества Wordpress над другими CMS-системами'),
(124, 49, '_title', 'field_61d44b137cfc5'),
(125, 49, 'text', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est, sit veniam atque libero voluptatibus repellat pariatur earum natus eos! Reiciendis qui odit suscipit aliquid soluta pariatur, repudiandae in minus animi? Sunt, commodi. Accusantium quibusdam suscipit sint vitae sunt dolore quos quaerat. Maxime voluptate neque repellendus unde nisi deleniti doloribus, aut nulla quam enim dicta mollitia voluptatibus ex quis nostrum eveniet ut eum totam consequuntur aspernatur corrupti. Ab nostrum temporibus deserunt consequatur architecto eius reprehenderit quidem, quae sit saepe soluta voluptatum, autem necessitatibus voluptates quibusdam nemo. Enim porro repellat maxime fuga quis incidunt ad, officiis quod? Et, eius? Officia, ipsam tenetur!'),
(126, 49, '_text', 'field_61d44b917cfc6'),
(127, 49, 'category', 'Программирование'),
(128, 49, '_category', 'field_61d44bb77cfc7'),
(129, 49, 'image', '47'),
(130, 49, '_image', 'field_61d44cd27cfc8'),
(133, 51, 'title', 'Преимущества Wordpress над другими CMS-системами'),
(134, 51, '_title', 'field_61d44b137cfc5'),
(135, 51, 'text', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est, sit veniam atque libero voluptatibus repellat pariatur earum natus eos! Reiciendis qui odit suscipit aliquid soluta pariatur, repudiandae in minus animi? Sunt, commodi. Accusantium quibusdam suscipit sint vitae sunt dolore quos quaerat. Maxime voluptate neque repellendus unde nisi deleniti doloribus, aut nulla quam enim dicta mollitia voluptatibus ex quis nostrum eveniet ut eum totam consequuntur aspernatur corrupti. Ab nostrum temporibus deserunt consequatur architecto eius reprehenderit quidem, quae sit saepe soluta voluptatum, autem necessitatibus voluptates quibusdam nemo. Enim porro repellat maxime fuga quis incidunt ad, officiis quod? Et, eius? Officia, ipsam tenetur!'),
(136, 51, '_text', 'field_61d44b917cfc6'),
(137, 51, 'category', 'Программирование'),
(138, 51, '_category', 'field_61d44bb77cfc7'),
(139, 51, 'image', '47'),
(140, 51, '_image', 'field_61d44cd27cfc8'),
(143, 53, 'title', 'Преимущества Wordpress над другими CMS-системами'),
(144, 53, '_title', 'field_61d44b137cfc5'),
(145, 53, 'text', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est, sit veniam atque libero voluptatibus repellat pariatur earum natus eos! Reiciendis qui odit suscipit aliquid soluta pariatur, repudiandae in minus animi? Sunt, commodi. Accusantium quibusdam suscipit sint vitae sunt dolore quos quaerat. Maxime voluptate neque repellendus unde nisi deleniti doloribus, aut nulla quam enim dicta mollitia voluptatibus ex quis nostrum eveniet ut eum totam consequuntur aspernatur corrupti. Ab nostrum temporibus deserunt consequatur architecto eius reprehenderit quidem, quae sit saepe soluta voluptatum, autem necessitatibus voluptates quibusdam nemo. Enim porro repellat maxime fuga quis incidunt ad, officiis quod? Et, eius? Officia, ipsam tenetur!'),
(146, 53, '_text', 'field_61d44b917cfc6'),
(147, 53, 'category', 'Программирование'),
(148, 53, '_category', 'field_61d44bb77cfc7'),
(149, 53, 'image', '47'),
(150, 53, '_image', 'field_61d44cd27cfc8'),
(151, 55, '_edit_lock', '1643550815:1'),
(152, 55, '_edit_last', '1'),
(153, 55, '_wp_page_template', 'index.php'),
(154, 57, '_edit_last', '1'),
(155, 57, '_edit_lock', '1725002008:1'),
(158, 1, 'price', '50'),
(159, 1, '_price', 'field_61f54d4c109b3'),
(160, 63, 'articles', ''),
(161, 63, '_articles', 'field_61d44a6be06ed'),
(162, 63, 'title', 'Почему PHP - плохой язык программирования?'),
(163, 63, '_title', 'field_61d44b137cfc5'),
(164, 63, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(165, 63, '_text', 'field_61d44b917cfc6') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(166, 63, 'category', 'Программирование'),
(167, 63, '_category', 'field_61d44bb77cfc7'),
(168, 63, 'image', '41'),
(169, 63, '_image', 'field_61d44cd27cfc8'),
(170, 63, 'price', '9.99'),
(171, 63, '_price', 'field_61f54d4c109b3'),
(174, 46, 'price', '50'),
(175, 46, '_price', 'field_61f54d4c109b3'),
(176, 64, 'title', 'Преимущества Wordpress над другими CMS-системами'),
(177, 64, '_title', 'field_61d44b137cfc5'),
(178, 64, 'text', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est, sit veniam atque libero voluptatibus repellat pariatur earum natus eos! Reiciendis qui odit suscipit aliquid soluta pariatur, repudiandae in minus animi? Sunt, commodi. Accusantium quibusdam suscipit sint vitae sunt dolore quos quaerat. Maxime voluptate neque repellendus unde nisi deleniti doloribus, aut nulla quam enim dicta mollitia voluptatibus ex quis nostrum eveniet ut eum totam consequuntur aspernatur corrupti. Ab nostrum temporibus deserunt consequatur architecto eius reprehenderit quidem, quae sit saepe soluta voluptatum, autem necessitatibus voluptates quibusdam nemo. Enim porro repellat maxime fuga quis incidunt ad, officiis quod? Et, eius? Officia, ipsam tenetur!'),
(179, 64, '_text', 'field_61d44b917cfc6'),
(180, 64, 'category', 'Программирование'),
(181, 64, '_category', 'field_61d44bb77cfc7'),
(182, 64, 'image', '47'),
(183, 64, '_image', 'field_61d44cd27cfc8'),
(184, 64, 'price', '9.99'),
(185, 64, '_price', 'field_61f54d4c109b3'),
(186, 55, 'articles', 'a:4:{i:0;s:1:"1";i:1;s:2:"46";i:2;s:2:"71";i:3;s:2:"75";}'),
(187, 55, '_articles', 'field_61d704dc024ed'),
(188, 65, 'articles', 'a:2:{i:0;s:1:"1";i:1;s:2:"46";}'),
(189, 65, '_articles', 'field_61d704dc024ed'),
(190, 66, 'articles', 'a:2:{i:0;s:1:"1";i:1;s:2:"46";}'),
(191, 66, '_articles', 'field_61d704dc024ed'),
(192, 55, 'test', 'test'),
(193, 55, '_test', 'field_61f58291f7e27'),
(194, 68, 'articles', 'a:2:{i:0;s:1:"1";i:1;s:2:"46";}'),
(195, 68, '_articles', 'field_61d704dc024ed'),
(196, 68, 'test', 'test'),
(197, 68, '_test', 'field_61f58291f7e27'),
(200, 69, 'title', 'Преимущества Wordpress над другими CMS-системами'),
(201, 69, '_title', 'field_61d44b137cfc5'),
(202, 69, 'text', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est, sit veniam atque libero voluptatibus repellat pariatur earum natus eos! Reiciendis qui odit suscipit aliquid soluta pariatur, repudiandae in minus animi? Sunt, commodi. Accusantium quibusdam suscipit sint vitae sunt dolore quos quaerat. Maxime voluptate neque repellendus unde nisi deleniti doloribus, aut nulla quam enim dicta mollitia voluptatibus ex quis nostrum eveniet ut eum totam consequuntur aspernatur corrupti. Ab nostrum temporibus deserunt consequatur architecto eius reprehenderit quidem, quae sit saepe soluta voluptatum, autem necessitatibus voluptates quibusdam nemo. Enim porro repellat maxime fuga quis incidunt ad, officiis quod? Et, eius? Officia, ipsam tenetur!'),
(203, 69, '_text', 'field_61d44b917cfc6'),
(204, 69, 'category', 'Программирование'),
(205, 69, '_category', 'field_61d44bb77cfc7'),
(206, 69, 'image', '47'),
(207, 69, '_image', 'field_61d44cd27cfc8'),
(208, 69, 'price', '50'),
(209, 69, '_price', 'field_61f54d4c109b3'),
(212, 70, 'articles', ''),
(213, 70, '_articles', 'field_61d44a6be06ed'),
(214, 70, 'title', 'Почему PHP - плохой язык программирования?'),
(215, 70, '_title', 'field_61d44b137cfc5'),
(216, 70, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(217, 70, '_text', 'field_61d44b917cfc6'),
(218, 70, 'category', 'Программирование'),
(219, 70, '_category', 'field_61d44bb77cfc7'),
(220, 70, 'image', '41'),
(221, 70, '_image', 'field_61d44cd27cfc8'),
(222, 70, 'price', '50'),
(223, 70, '_price', 'field_61f54d4c109b3'),
(224, 71, '_edit_lock', '1643548690:1'),
(229, 71, '_edit_last', '1'),
(230, 71, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(231, 71, '_text', 'field_61d44b917cfc6'),
(232, 71, 'category', 'Программирование'),
(233, 71, '_category', 'field_61d44bb77cfc7'),
(234, 71, 'image', '80'),
(235, 71, '_image', 'field_61d44cd27cfc8'),
(236, 71, 'price', '50'),
(237, 71, '_price', 'field_61f54d4c109b3'),
(238, 74, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(239, 74, '_text', 'field_61d44b917cfc6'),
(240, 74, 'category', 'Программирование'),
(241, 74, '_category', 'field_61d44bb77cfc7'),
(242, 74, 'image', '72'),
(243, 74, '_image', 'field_61d44cd27cfc8'),
(244, 74, 'price', '50'),
(245, 74, '_price', 'field_61f54d4c109b3'),
(246, 75, '_edit_lock', '1725006039:1'),
(247, 76, '_wp_attached_file', '2022/01/recaptcha.png'),
(248, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:21:"2022/01/recaptcha.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:21:"recaptcha-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:23:"recaptcha-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:21:"recaptcha-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:21:"recaptcha-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(251, 75, '_edit_last', '1'),
(252, 75, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(253, 75, '_text', 'field_61d44b917cfc6'),
(254, 75, 'category', 'Безопасность'),
(255, 75, '_category', 'field_61d44bb77cfc7'),
(256, 75, 'image', '76'),
(257, 75, '_image', 'field_61d44cd27cfc8'),
(258, 75, 'price', '50'),
(259, 75, '_price', 'field_61f54d4c109b3'),
(260, 78, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(261, 78, '_text', 'field_61d44b917cfc6'),
(262, 78, 'category', 'Безопасность'),
(263, 78, '_category', 'field_61d44bb77cfc7'),
(264, 78, 'image', '76'),
(265, 78, '_image', 'field_61d44cd27cfc8'),
(266, 78, 'price', '50'),
(267, 78, '_price', 'field_61f54d4c109b3'),
(268, 79, 'articles', 'a:4:{i:0;s:1:"1";i:1;s:2:"46";i:2;s:2:"71";i:3;s:2:"75";}'),
(269, 79, '_articles', 'field_61d704dc024ed'),
(270, 79, 'test', 'test'),
(271, 79, '_test', 'field_61f58291f7e27'),
(272, 80, '_wp_attached_file', '2022/01/programming.png'),
(273, 80, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1280;s:6:"height";i:720;s:4:"file";s:23:"2022/01/programming.png";s:5:"sizes";a:4:{s:6:"medium";a:4:{s:4:"file";s:23:"programming-300x169.png";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:24:"programming-1024x576.png";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:9:"image/png";}s:9:"thumbnail";a:4:{s:4:"file";s:23:"programming-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:23:"programming-768x432.png";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(276, 81, 'text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(277, 81, '_text', 'field_61d44b917cfc6'),
(278, 81, 'category', 'Программирование'),
(279, 81, '_category', 'field_61d44bb77cfc7') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(280, 81, 'image', '80'),
(281, 81, '_image', 'field_61d44cd27cfc8'),
(282, 81, 'price', '50'),
(283, 81, '_price', 'field_61f54d4c109b3'),
(302, 9, 'articles', 'a:4:{i:0;s:1:"1";i:1;s:2:"46";i:2;s:2:"71";i:3;s:2:"75";}'),
(303, 9, '_articles', 'field_61d704dc024ed'),
(304, 90, 'articles', 'a:4:{i:0;s:1:"1";i:1;s:2:"46";i:2;s:2:"71";i:3;s:2:"75";}'),
(305, 90, '_articles', 'field_61d704dc024ed'),
(312, 11, 'articles', 'a:4:{i:0;s:1:"1";i:1;s:2:"46";i:2;s:2:"71";i:3;s:2:"75";}'),
(313, 11, '_articles', 'field_61d704dc024ed'),
(314, 95, 'articles', 'a:4:{i:0;s:1:"1";i:1;s:2:"46";i:2;s:2:"71";i:3;s:2:"75";}'),
(315, 95, '_articles', 'field_61d704dc024ed') ;

#
# Конец содержимого данных таблицы `wp_postmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Структура таблицы `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-12-30 23:24:15', '2021-12-30 20:24:15', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Почему PHP - плохой язык программирования?', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2022-01-29 23:04:12', '2022-01-29 20:04:12', '', 0, 'http://blog.com/?p=1', 0, 'post', '', 0),
(9, 1, '2021-12-31 19:50:22', '2021-12-31 16:50:22', '', 'Все статьи', '', 'publish', 'closed', 'closed', '', 'articles', '', '', '2022-01-31 09:21:57', '2022-01-31 06:21:57', '', 0, 'http://blog.com/?page_id=9', 0, 'page', '', 0),
(11, 1, '2021-12-31 19:50:51', '2021-12-31 16:50:51', '', 'Статья', '', 'publish', 'closed', 'closed', '', 'article', '', '', '2022-01-30 23:50:48', '2022-01-30 20:50:48', '', 0, 'http://blog.com/?page_id=11', 0, 'page', '', 0),
(13, 1, '2021-12-31 22:35:27', '2021-12-31 19:35:27', '', 'Обо мне', '', 'publish', 'closed', 'closed', '', 'about-me', '', '', '2022-01-30 23:26:27', '2022-01-30 20:26:27', '', 0, 'http://blog.com/?page_id=13', 0, 'page', '', 0),
(15, 1, '2021-12-31 22:36:32', '2021-12-31 19:36:32', '', 'Правообладателям', '', 'publish', 'closed', 'closed', '', 'copyright', '', '', '2022-01-30 23:26:35', '2022-01-30 20:26:35', '', 0, 'http://blog.com/?page_id=15', 0, 'page', '', 0),
(20, 1, '2022-01-01 22:58:35', '2022-01-01 19:58:35', '', 'polylang_mo_6', '', 'private', 'closed', 'closed', '', 'polylang_mo_6', '', '', '2022-01-01 22:58:35', '2022-01-01 19:58:35', '', 0, 'http://blog.com/?post_type=polylang_mo&p=20', 0, 'polylang_mo', '', 0),
(21, 1, '2022-01-01 22:59:01', '2022-01-01 19:59:01', '', 'polylang_mo_8', '', 'private', 'closed', 'closed', '', 'polylang_mo_8', '', '', '2022-01-01 22:59:01', '2022-01-01 19:59:01', '', 0, 'http://blog.com/?post_type=polylang_mo&p=21', 0, 'polylang_mo', '', 0),
(22, 1, '2022-01-01 22:59:51', '2022-01-01 19:59:51', '', 'polylang_mo_11', '', 'private', 'closed', 'closed', '', 'polylang_mo_11', '', '', '2022-01-01 22:59:51', '2022-01-01 19:59:51', '', 0, 'http://blog.com/?post_type=polylang_mo&p=22', 0, 'polylang_mo', '', 0),
(34, 1, '2022-01-04 16:35:46', '2022-01-04 13:35:46', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Шаблон платных статей', '%d1%88%d0%b0%d0%b1%d0%bb%d0%be%d0%bd-%d0%bf%d0%bb%d0%b0%d1%82%d0%bd%d1%8b%d1%85-%d1%81%d1%82%d0%b0%d1%82%d0%b5%d0%b9', 'publish', 'closed', 'closed', '', 'group_61d44af87f06c', '', '', '2022-02-01 09:36:37', '2022-02-01 06:36:37', '', 0, 'http://blog.com/?post_type=acf-field-group&#038;p=34', 0, 'acf-field-group', '', 0),
(36, 1, '2022-01-04 16:35:46', '2022-01-04 13:35:46', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Текст статьи', 'text', 'publish', 'closed', 'closed', '', 'field_61d44b917cfc6', '', '', '2022-02-01 09:36:37', '2022-02-01 06:36:37', '', 34, 'http://blog.com/?post_type=acf-field&#038;p=36', 0, 'acf-field', '', 0),
(37, 1, '2022-01-04 16:35:46', '2022-01-04 13:35:46', 'a:13:{s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:10:{s:10:"Спорт";s:10:"Спорт";s:18:"Кулинария";s:18:"Кулинария";s:22:"Садоводство";s:22:"Садоводство";s:32:"Программирование";s:32:"Программирование";s:9:"Lifestyle";s:9:"Lifestyle";s:8:"Игры";s:8:"Игры";s:24:"Безопасность";s:24:"Безопасность";s:18:"Хакерство";s:18:"Хакерство";s:14:"Природа";s:14:"Природа";s:12:"Разное";s:12:"Разное";}s:13:"default_value";b:0;s:10:"allow_null";i:0;s:8:"multiple";i:0;s:2:"ui";i:0;s:13:"return_format";s:5:"value";s:4:"ajax";i:0;s:11:"placeholder";s:0:"";}', 'Категория статьи', 'category', 'publish', 'closed', 'closed', '', 'field_61d44bb77cfc7', '', '', '2022-01-06 17:23:52', '2022-01-06 14:23:52', '', 34, 'http://blog.com/?post_type=acf-field&#038;p=37', 1, 'acf-field', '', 0),
(38, 1, '2022-01-04 16:35:46', '2022-01-04 13:35:46', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение статьи', 'image', 'publish', 'closed', 'closed', '', 'field_61d44cd27cfc8', '', '', '2022-01-06 17:23:52', '2022-01-06 14:23:52', '', 34, 'http://blog.com/?post_type=acf-field&#038;p=38', 2, 'acf-field', '', 0),
(39, 1, '2022-01-04 16:39:26', '2022-01-04 13:39:26', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Почему PHP - плохой язык программирования?', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-01-04 16:39:26', '2022-01-04 13:39:26', '', 1, 'http://blog.com/?p=39', 0, 'revision', '', 0),
(40, 1, '2022-01-04 16:39:30', '2022-01-04 13:39:30', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Почему PHP - плохой язык программирования?', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-01-04 16:39:30', '2022-01-04 13:39:30', '', 1, 'http://blog.com/?p=40', 0, 'revision', '', 0),
(41, 1, '2022-01-04 16:44:52', '2022-01-04 13:44:52', '', 'php', '', 'inherit', 'open', 'closed', '', 'php', '', '', '2022-01-04 16:44:52', '2022-01-04 13:44:52', '', 1, 'http://blog.com/wp-content/uploads/2021/12/php.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2022-01-04 16:45:28', '2022-01-04 13:45:28', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Почему PHP - плохой язык программирования?', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-01-04 16:45:28', '2022-01-04 13:45:28', '', 1, 'http://blog.com/?p=42', 0, 'revision', '', 0),
(46, 1, '2022-01-06 17:01:29', '2022-01-06 14:01:29', '', 'Преимущества Wordpress над другими CMS-системами', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b5%d0%b8%d0%bc%d1%83%d1%89%d0%b5%d1%81%d1%82%d0%b2%d0%b0-wordpress-%d0%bd%d0%b0%d0%b4-%d0%b4%d1%80%d1%83%d0%b3%d0%b8%d0%bc%d0%b8-cms-%d1%81%d0%b8%d1%81%d1%82%d0%b5%d0%bc%d0%b0%d0%bc', '', '', '2022-01-29 23:03:48', '2022-01-29 20:03:48', '', 0, 'http://blog.com/?p=46', 0, 'post', '', 0),
(47, 1, '2022-01-06 17:01:14', '2022-01-06 14:01:14', '', 'wordpress', '', 'inherit', 'open', 'closed', '', 'wordpress', '', '', '2022-01-06 17:01:14', '2022-01-06 14:01:14', '', 46, 'http://blog.com/wp-content/uploads/2022/01/wordpress.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2022-01-06 17:01:29', '2022-01-06 14:01:29', '', 'Преимущества Wordpress над другими CMS-системами', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-06 17:01:29', '2022-01-06 14:01:29', '', 46, 'http://blog.com/?p=48', 0, 'revision', '', 0),
(49, 1, '2022-01-06 17:01:33', '2022-01-06 14:01:33', '', 'Преимущества Wordpress над другими CMS-системами', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-06 17:01:33', '2022-01-06 14:01:33', '', 46, 'http://blog.com/?p=49', 0, 'revision', '', 0),
(50, 1, '2022-01-06 17:19:22', '2022-01-06 14:19:22', '', 'Преимущества Wordpress над другими CMS-системами!', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-06 17:19:22', '2022-01-06 14:19:22', '', 46, 'http://blog.com/?p=50', 0, 'revision', '', 0),
(51, 1, '2022-01-06 17:19:26', '2022-01-06 14:19:26', '', 'Преимущества Wordpress над другими CMS-системами!', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-06 17:19:26', '2022-01-06 14:19:26', '', 46, 'http://blog.com/?p=51', 0, 'revision', '', 0),
(52, 1, '2022-01-06 17:22:15', '2022-01-06 14:22:15', '', 'Преимущества Wordpress над другими CMS-системами', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-06 17:22:15', '2022-01-06 14:22:15', '', 46, 'http://blog.com/?p=52', 0, 'revision', '', 0),
(53, 1, '2022-01-06 17:22:19', '2022-01-06 14:22:19', '', 'Преимущества Wordpress над другими CMS-системами', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-06 17:22:19', '2022-01-06 14:22:19', '', 46, 'http://blog.com/?p=53', 0, 'revision', '', 0),
(55, 1, '2022-01-06 17:51:55', '2022-01-06 14:51:55', '', 'Главная страница', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0', '', '', '2022-01-30 16:53:35', '2022-01-30 13:53:35', '', 0, 'http://blog.com/?page_id=55', 0, 'page', '', 0),
(56, 1, '2022-01-06 17:51:55', '2022-01-06 14:51:55', '', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-01-06 17:51:55', '2022-01-06 14:51:55', '', 55, 'http://blog.com/?p=56', 0, 'revision', '', 0),
(57, 1, '2022-01-06 18:04:55', '2022-01-06 15:04:55', 'a:8:{s:8:"location";a:3:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"55";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"9";}}i:2;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"11";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Главная страница', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0', 'publish', 'closed', 'closed', '', 'group_61d702f0c708b', '', '', '2022-01-30 23:50:00', '2022-01-30 20:50:00', '', 0, 'http://blog.com/?post_type=acf-field-group&#038;p=57', 0, 'acf-field-group', '', 0),
(58, 1, '2022-01-06 18:04:55', '2022-01-06 15:04:55', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Вкладка статей', 'статьи', 'publish', 'closed', 'closed', '', 'field_61d704ac024ec', '', '', '2022-01-06 18:04:55', '2022-01-06 15:04:55', '', 57, 'http://blog.com/?post_type=acf-field&p=58', 0, 'acf-field', '', 0),
(59, 1, '2022-01-06 18:04:55', '2022-01-06 15:04:55', 'a:11:{s:4:"type";s:11:"post_object";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"post";}s:8:"taxonomy";s:0:"";s:10:"allow_null";i:1;s:8:"multiple";i:1;s:13:"return_format";s:6:"object";s:2:"ui";i:1;}', 'Статьи', 'articles', 'publish', 'closed', 'closed', '', 'field_61d704dc024ed', '', '', '2022-01-29 21:00:26', '2022-01-29 18:00:26', '', 57, 'http://blog.com/?post_type=acf-field&#038;p=59', 1, 'acf-field', '', 0),
(61, 1, '2022-01-29 13:44:09', '2022-01-29 10:44:09', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-blog', '', '', '2022-01-29 13:44:09', '2022-01-29 10:44:09', '', 0, 'http://blog.com/2022/01/29/wp-global-styles-blog/', 0, 'wp_global_styles', '', 0),
(62, 1, '2022-01-29 17:22:03', '2022-01-29 14:22:03', 'a:12:{s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";}', 'Стоимость статьи (в гривнах)', 'price', 'publish', 'closed', 'closed', '', 'field_61f54d4c109b3', '', '', '2022-01-29 23:04:35', '2022-01-29 20:04:35', '', 34, 'http://blog.com/?post_type=acf-field&#038;p=62', 3, 'acf-field', '', 0),
(63, 1, '2022-01-29 17:28:45', '2022-01-29 14:28:45', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Почему PHP - плохой язык программирования?', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-01-29 17:28:45', '2022-01-29 14:28:45', '', 1, 'http://blog.com/?p=63', 0, 'revision', '', 0),
(64, 1, '2022-01-29 17:29:18', '2022-01-29 14:29:18', '', 'Преимущества Wordpress над другими CMS-системами', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-29 17:29:18', '2022-01-29 14:29:18', '', 46, 'http://blog.com/?p=64', 0, 'revision', '', 0),
(65, 1, '2022-01-29 21:05:45', '2022-01-29 18:05:45', '', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-01-29 21:05:45', '2022-01-29 18:05:45', '', 55, 'http://blog.com/?p=65', 0, 'revision', '', 0),
(66, 1, '2022-01-29 21:06:23', '2022-01-29 18:06:23', '', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-01-29 21:06:23', '2022-01-29 18:06:23', '', 55, 'http://blog.com/?p=66', 0, 'revision', '', 0),
(68, 1, '2022-01-29 21:09:29', '2022-01-29 18:09:29', '', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-01-29 21:09:29', '2022-01-29 18:09:29', '', 55, 'http://blog.com/?p=68', 0, 'revision', '', 0),
(69, 1, '2022-01-29 23:03:48', '2022-01-29 20:03:48', '', 'Преимущества Wordpress над другими CMS-системами', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2022-01-29 23:03:48', '2022-01-29 20:03:48', '', 46, 'http://blog.com/?p=69', 0, 'revision', '', 0),
(70, 1, '2022-01-29 23:04:12', '2022-01-29 20:04:12', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Почему PHP - плохой язык программирования?', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-01-29 23:04:12', '2022-01-29 20:04:12', '', 1, 'http://blog.com/?p=70', 0, 'revision', '', 0),
(71, 1, '2022-01-30 15:32:37', '2022-01-30 12:32:37', '', 'Какой язык программирования стоит учить в феврале 2022 года?', '', 'publish', 'open', 'open', '', '%d0%ba%d0%b0%d0%ba%d0%be%d0%b9-%d1%8f%d0%b7%d1%8b%d0%ba-%d0%bf%d1%80%d0%be%d0%b3%d1%80%d0%b0%d0%bc%d0%bc%d0%b8%d1%80%d0%be%d0%b2%d0%b0%d0%bd%d0%b8%d1%8f-%d1%81%d1%82%d0%be%d0%b8%d1%82-%d1%83%d1%87', '', '', '2022-01-30 15:42:12', '2022-01-30 12:42:12', '', 0, 'http://blog.com/?p=71', 0, 'post', '', 0),
(73, 1, '2022-01-30 15:32:37', '2022-01-30 12:32:37', '', 'Какой язык программирования стоит учить в феврале 2022 года?', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2022-01-30 15:32:37', '2022-01-30 12:32:37', '', 71, 'http://blog.com/?p=73', 0, 'revision', '', 0),
(74, 1, '2022-01-30 15:32:41', '2022-01-30 12:32:41', '', 'Какой язык программирования стоит учить в феврале 2022 года?', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2022-01-30 15:32:41', '2022-01-30 12:32:41', '', 71, 'http://blog.com/?p=74', 0, 'revision', '', 0),
(75, 1, '2022-01-30 15:37:10', '2022-01-30 12:37:10', '', 'Единственный способ защитить свой веб-сайт от хакеров раз и на всегда!', '', 'publish', 'open', 'open', '', '%d0%b5%d0%b4%d0%b8%d0%bd%d1%81%d1%82%d0%b2%d0%b5%d0%bd%d0%bd%d1%8b%d0%b9-%d1%81%d0%bf%d0%be%d1%81%d0%be%d0%b1-%d0%b7%d0%b0%d1%89%d0%b8%d1%82%d0%b8%d1%82%d1%8c-%d1%81%d0%b2%d0%be%d0%b9-%d0%b2%d0%b5', '', '', '2022-01-30 15:37:15', '2022-01-30 12:37:15', '', 0, 'http://blog.com/?p=75', 0, 'post', '', 0),
(76, 1, '2022-01-30 15:36:56', '2022-01-30 12:36:56', '', 'recaptcha', '', 'inherit', 'open', 'closed', '', 'recaptcha', '', '', '2022-01-30 15:36:56', '2022-01-30 12:36:56', '', 75, 'http://blog.com/wp-content/uploads/2022/01/recaptcha.png', 0, 'attachment', 'image/png', 0),
(77, 1, '2022-01-30 15:37:10', '2022-01-30 12:37:10', '', 'Единственный способ защитить свой веб-сайт от хакеров раз и на всегда!', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2022-01-30 15:37:10', '2022-01-30 12:37:10', '', 75, 'http://blog.com/?p=77', 0, 'revision', '', 0),
(78, 1, '2022-01-30 15:37:15', '2022-01-30 12:37:15', '', 'Единственный способ защитить свой веб-сайт от хакеров раз и на всегда!', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2022-01-30 15:37:15', '2022-01-30 12:37:15', '', 75, 'http://blog.com/?p=78', 0, 'revision', '', 0),
(79, 1, '2022-01-30 15:37:51', '2022-01-30 12:37:51', '', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2022-01-30 15:37:51', '2022-01-30 12:37:51', '', 55, 'http://blog.com/?p=79', 0, 'revision', '', 0),
(80, 1, '2022-01-30 15:41:59', '2022-01-30 12:41:59', '', 'programming', '', 'inherit', 'open', 'closed', '', 'programming', '', '', '2022-01-30 15:41:59', '2022-01-30 12:41:59', '', 71, 'http://blog.com/wp-content/uploads/2022/01/programming.png', 0, 'attachment', 'image/png', 0),
(81, 1, '2022-01-30 15:42:12', '2022-01-30 12:42:12', '', 'Какой язык программирования стоит учить в феврале 2022 года?', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2022-01-30 15:42:12', '2022-01-30 12:42:12', '', 71, 'http://blog.com/?p=81', 0, 'revision', '', 0),
(84, 1, '2022-01-30 16:20:37', '2022-01-30 13:20:37', '', 'Обо мне', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2022-01-30 16:20:37', '2022-01-30 13:20:37', '', 13, 'http://blog.com/?p=84', 0, 'revision', '', 0),
(89, 1, '2022-01-30 17:27:19', '2022-01-30 14:27:19', '', 'Все статьи', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2022-01-30 17:27:19', '2022-01-30 14:27:19', '', 9, 'http://blog.com/?p=89', 0, 'revision', '', 0),
(90, 1, '2022-01-30 17:30:06', '2022-01-30 14:30:06', '', 'Все статьи', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2022-01-30 17:30:06', '2022-01-30 14:30:06', '', 9, 'http://blog.com/?p=90', 0, 'revision', '', 0),
(93, 1, '2022-01-30 23:11:22', '2022-01-30 20:11:22', '', 'Правообладателям', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2022-01-30 23:11:22', '2022-01-30 20:11:22', '', 15, 'http://blog.com/?p=93', 0, 'revision', '', 0),
(94, 1, '2022-01-30 23:11:32', '2022-01-30 20:11:32', '', 'Статья', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2022-01-30 23:11:32', '2022-01-30 20:11:32', '', 11, 'http://blog.com/?p=94', 0, 'revision', '', 0),
(95, 1, '2022-01-30 23:50:48', '2022-01-30 20:50:48', '', 'Статья', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2022-01-30 23:50:48', '2022-01-30 20:50:48', '', 11, 'http://blog.com/?p=95', 0, 'revision', '', 0),
(103, 1, '2025-06-26 20:06:33', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2025-06-26 20:06:33', '0000-00-00 00:00:00', '', 0, 'https://itshnik.42web.io/?p=103', 0, 'post', '', 0) ;

#
# Конец содержимого данных таблицы `wp_posts`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_quads_stats`
#

DROP TABLE IF EXISTS `wp_quads_stats`;


#
# Структура таблицы `wp_quads_stats`
#

CREATE TABLE `wp_quads_stats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int unsigned NOT NULL DEFAULT '0',
  `ad_thetime` int unsigned NOT NULL DEFAULT '0',
  `ad_clicks` int unsigned NOT NULL DEFAULT '0',
  `ad_impressions` int unsigned NOT NULL DEFAULT '0',
  `ad_device_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `ip_address` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `URL` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `referrer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `ad_id` (`ad_id`),
  KEY `ad_thetime` (`ad_thetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_quads_stats`
#

#
# Конец содержимого данных таблицы `wp_quads_stats`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Структура таблицы `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 9, 0),
(1, 10, 0),
(9, 6, 0),
(9, 16, 0),
(11, 6, 0),
(13, 6, 0),
(13, 10, 0),
(13, 12, 0),
(15, 6, 0),
(23, 6, 0),
(25, 8, 0),
(25, 16, 0),
(27, 11, 0),
(27, 16, 0),
(46, 1, 0),
(61, 17, 0),
(71, 1, 0),
(75, 1, 0) ;

#
# Конец содержимого данных таблицы `wp_term_relationships`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Структура таблицы `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 4),
(6, 6, 'language', 'a:3:{s:6:"locale";s:5:"ru_RU";s:3:"rtl";i:0;s:9:"flag_code";s:2:"ru";}', 0, 4),
(7, 7, 'term_language', '', 0, 0),
(8, 8, 'language', 'a:3:{s:6:"locale";s:2:"uk";s:3:"rtl";i:0;s:9:"flag_code";s:2:"ua";}', 0, 1),
(9, 9, 'term_language', '', 0, 1),
(10, 10, 'term_translations', 'a:2:{s:2:"uk";i:1;s:2:"en";i:13;}', 0, 2),
(11, 11, 'language', 'a:3:{s:6:"locale";s:5:"en_US";s:3:"rtl";i:0;s:9:"flag_code";s:2:"us";}', 0, 1),
(12, 12, 'term_language', '', 0, 1),
(13, 13, 'category', '', 0, 0),
(16, 16, 'post_translations', 'a:3:{s:2:"uk";i:25;s:2:"ru";i:9;s:2:"en";i:27;}', 0, 3),
(17, 17, 'wp_theme', '', 0, 1) ;

#
# Конец содержимого данных таблицы `wp_term_taxonomy`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Структура таблицы `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_termmeta`
#

#
# Конец содержимого данных таблицы `wp_termmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Структура таблицы `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(6, 'Русский', 'ru', 0),
(7, 'Русский', 'pll_ru', 0),
(8, 'Українська', 'uk', 1),
(9, 'Українська', 'pll_uk', 0),
(10, 'pll_61d0b285317db', 'pll_61d0b285317db', 0),
(11, 'English', 'en', 2),
(12, 'English', 'pll_en', 0),
(13, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8-en', 0),
(16, 'pll_61d0b4e8b223a', 'pll_61d0b4e8b223a', 0),
(17, 'Blog', 'blog', 0) ;

#
# Конец содержимого данных таблицы `wp_terms`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Структура таблицы `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Ilya Bashlyaev'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', 'ru_RU'),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wpquads_subscribe_pointer'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:4:{s:64:"1786f4c0a70f784635e44c52ab988e4112fc1f3c4f3219e817155813d06babe2";a:4:{s:10:"expiration";i:1751130389;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:139.0) Gecko/20100101 Firefox/139.0";s:5:"login";i:1750957589;}s:64:"2b639460b2535b124ebb59e3250a63cbab6b629056d0126740e77425e6c001e8";a:4:{s:10:"expiration";i:1751131176;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:139.0) Gecko/20100101 Firefox/139.0";s:5:"login";i:1750958376;}s:64:"72a6c6d73f3986e365f574ae74f834bc932eb4f786e267e56a2684fa45707eec";a:4:{s:10:"expiration";i:1751131556;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:139.0) Gecko/20100101 Firefox/139.0";s:5:"login";i:1750958756;}s:64:"5148550b0eacee88561d1d7b8fb3f2b1182fd9c1cbc3d7f5978cbf1301681cfa";a:4:{s:10:"expiration";i:1751188352;s:2:"ip";s:3:"::1";s:2:"ua";s:84:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:139.0) Gecko/20100101 Firefox/139.0";s:5:"login";i:1751015552;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '103'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'pll_filter_content', 'ru'),
(20, 1, 'closedpostboxes_page', 'a:1:{i:0;s:6:"ml_box";}'),
(21, 1, 'metaboxhidden_page', 'a:0:{}'),
(22, 1, 'closedpostboxes_dashboard', 'a:3:{i:0;s:19:"dashboard_right_now";i:1;s:18:"dashboard_activity";i:2;s:17:"dashboard_primary";}'),
(23, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(25, 1, 'rocketcdn_dismiss_notice', '1'),
(26, 1, 'quads_adsense_pub_id', 'ca-pub-8485558309118681'),
(27, 1, 'closedpostboxes_post', 'a:0:{}'),
(28, 1, 'metaboxhidden_post', 'a:0:{}'),
(29, 1, 'wp_user-settings', 'libraryContent=browse'),
(30, 1, 'wp_user-settings-time', '1641303927'),
(31, 1, 'wp_googlesitekit_tracking_optin', '1'),
(33, 1, 'wp_googlesitekit_site_verification_file', '9057cceaef34c861'),
(34, 1, 'wp_googlesitekit_site_verification_meta', 'oLV7v1bfT_Zze43v1udm0mAhzEgiWmNppBfu92oLsUA'),
(35, 1, 'w3tc_features_seen', 'a:2:{i:1;s:12:"imageservice";i:2;s:11:"setup_guide";}'),
(36, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:60:"dashboard_site_health,dashboard_right_now,dashboard_activity";s:4:"side";s:39:"dashboard_quick_press,dashboard_primary";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'),
(37, 1, '_new_email', 'a:2:{s:4:"hash";s:32:"7ab1ef574eb9c0aec2b44f1a7bbceab8";s:8:"newemail";s:20:"ibashlyaev@gmail.com";}') ;

#
# Конец содержимого данных таблицы `wp_usermeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Структура таблицы `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Ilya', '$P$B8r0nf6q0wu/f6IjJBEqX7drq0EKRR/', 'ilya', 'i.bashlyaev@gmail.com', 'http://blog.com', '2021-12-30 20:24:15', '', 0, 'Ilya Bashlyaev') ;

#
# Конец содержимого данных таблицы `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

